@echo off
setlocal
cd /d "%~dp0"
call "%~dp0tools\windows-env.cmd"
if errorlevel 1 goto finish
"%TIDEBOOK_POWERSHELL%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\credentials.ps1" -Action reset-password
:finish
pause
endlocal
