@echo off
setlocal
cd /d "%~dp0"
call "%~dp0tools\windows-env.cmd"
if errorlevel 1 goto finish
echo Close the server and tunnel windows before continuing.
pause
"%TIDEBOOK_NODE%" server/admin.mjs backup
:finish
pause
endlocal
