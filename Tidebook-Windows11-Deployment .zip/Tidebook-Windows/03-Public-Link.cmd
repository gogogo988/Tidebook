@echo off
setlocal
cd /d "%~dp0"
call "%~dp0tools\windows-env.cmd"
if errorlevel 1 goto finish
"%TIDEBOOK_NODE%" tools/tunnel.mjs
:finish
pause
endlocal
