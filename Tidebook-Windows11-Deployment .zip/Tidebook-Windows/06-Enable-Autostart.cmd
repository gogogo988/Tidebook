@echo off
setlocal
cd /d "%~dp0"
call "%~dp0tools\windows-env.cmd"
if errorlevel 1 goto finish
"%TIDEBOOK_POWERSHELL%" -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\autostart.ps1"
:finish
pause
endlocal
