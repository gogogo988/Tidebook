import {scrypt,randomBytes,timingSafeEqual,createHash} from 'node:crypto';import {promisify} from 'node:util';const derive=promisify(scrypt);
export const token=()=>randomBytes(32).toString('hex');export const hash=s=>createHash('sha256').update(s).digest('hex');
export function validEmail(s){return typeof s==='string'&&s.length<=254&&/^\S+@[^\s@]+\.[^\s@]+$/.test(s)}
export async function passwordHash(password){if(typeof password!=='string'||password.length<6||password.length>12)throw Error('密码长度须为 6–12 个字符');const salt=randomBytes(16).toString('hex');const result=await derive(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024});return salt+':'+result.toString('hex')}
export async function passwordMatches(password,stored){if(typeof password!=='string'||password.length>128)return false;const [salt,hex]=stored.split(':');const result=await derive(password,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024});return timingSafeEqual(result,Buffer.from(hex,'hex'))}
