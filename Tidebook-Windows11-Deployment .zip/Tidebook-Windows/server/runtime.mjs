import {DatabaseSync} from 'node:sqlite';
import {AsyncLocalStorage} from 'node:async_hooks';
import {mkdirSync,readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {fileURLToPath} from 'node:url';import path from 'node:path';
export const root=fileURLToPath(new URL('../',import.meta.url));
export const dataDir=process.env.TIDEBOOK_DATA_DIR||path.join(root,'data');mkdirSync(path.join(dataDir,'files'),{recursive:true});
export const sqlite=new DatabaseSync(path.join(dataDir,'tidebook.sqlite'));sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
sqlite.exec('CREATE TABLE IF NOT EXISTS local_migrations(name TEXT PRIMARY KEY)');
for(const name of readdirSync(path.join(root,'source/drizzle')).filter(n=>n.endsWith('.sql')).sort()){if(!sqlite.prepare('SELECT name FROM local_migrations WHERE name=?').get(name)){sqlite.exec('BEGIN');try{sqlite.exec(readFileSync(path.join(root,'source/drizzle',name),'utf8'));sqlite.prepare('INSERT INTO local_migrations VALUES (?)').run(name);sqlite.exec('COMMIT')}catch(e){sqlite.exec('ROLLBACK');throw e}}}
sqlite.exec(`CREATE TABLE IF NOT EXISTS accounts(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,transfer_code TEXT NOT NULL);CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires INTEGER NOT NULL);`);
// Additive migration keeps existing accounts, passwords, sessions and bookings.
if(!sqlite.prepare('PRAGMA table_info(accounts)').all().some(c=>c.name==='username'))sqlite.exec("ALTER TABLE accounts ADD COLUMN username TEXT NOT NULL DEFAULT ''");
export const requestContext=new AsyncLocalStorage();
export async function getChatGPTUser(){return requestContext.getStore()?.user||null}
function statement(sql,args=[]){
 return {
  bind(...a){return statement(sql,a)},
  first(){return sqlite.prepare(sql).get(...args)||null},
  all(){return {results:sqlite.prepare(sql).all(...args)}},
  run(){return {meta:{changes:Number(sqlite.prepare(sql).run(...args).changes)}}}
 };
}
export const env={DB:{prepare:statement,batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const result=statements.map(s=>s.run());sqlite.exec('COMMIT');return result}catch(e){sqlite.exec('ROLLBACK');throw e}}},BUCKET:{async put(id,bytes){if(!/^[a-f0-9-]{36}$/.test(id))throw Error('Invalid file id');writeFileSync(path.join(dataDir,'files',id),Buffer.from(bytes),{flag:'wx'})},async get(id){if(!/^[a-f0-9-]{36}$/.test(id))return null;const f=path.join(dataDir,'files',id);return existsSync(f)?{body:readFileSync(f)}:null}}};
