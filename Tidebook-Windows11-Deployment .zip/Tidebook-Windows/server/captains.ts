import { env } from './runtime.mjs';
import { getChatGPTUser } from './runtime.mjs';
export type Captain = { userId:string; email:string };
export const normalizeEmail=(email:string)=>email.trim().toLowerCase();
export async function captainContext(){
 if(!env.DB)throw Error('数据库暂不可用');
 const u=await getChatGPTUser();
 const owner=await env.DB.prepare("SELECT value FROM settings WHERE key='owner'").first<{value:string}>();
 // Record signed-in identities. Email resolves a recipient; stable user IDs authorize access.
 if(u)await env.DB.prepare("INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").bind('identity:'+u.userId,JSON.stringify({userId:u.userId,email:normalizeEmail(u.email)})).run();
 let row=await env.DB.prepare("SELECT value FROM settings WHERE key='captains'").first<{value:string}>();
 if(!row&&u&&owner?.value===u.userId){
  await env.DB.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES ('captains',?)").bind(JSON.stringify([{userId:u.userId,email:normalizeEmail(u.email)}])).run();
  row=await env.DB.prepare("SELECT value FROM settings WHERE key='captains'").first<{value:string}>();
 }
 const captains:Captain[]=row?JSON.parse(row.value):owner?[{userId:owner.value,email:''}]:[];
 return {u,owner,admin:!!u&&captains.some(c=>c.userId===u.userId),captains,revision:row?.value??null};
}
export async function changeCaptains(p:any,ctx:Awaited<ReturnType<typeof captainContext>>){
 if(!env.DB||!ctx.admin||!ctx.u||!ctx.revision)throw Error('仅现任船长可管理权限');
 if(p.revision!==ctx.revision)throw Error('船长名单已变化，请刷新后重试');
 let next=[...ctx.captains];
 if(p.operation==='remove'){
  if(!next.some(c=>c.userId===p.targetId))throw Error('船长不存在');
  next=next.filter(c=>c.userId!==p.targetId);
 }else if(['add','replace'].includes(p.operation)){
  const email=typeof p.email==='string'?normalizeEmail(p.email):'';
  if(email.length>254||!/^\S+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('请输入完整有效的邮箱');
  const matches=await env.DB.prepare("SELECT value FROM settings WHERE key LIKE 'identity:%' AND json_extract(value,'$.email')=?").bind(email).all<{value:string}>();
  if(matches.results.length!==1)throw Error(matches.results.length?'此邮箱对应多个账户，无法安全转交权限':'未找到此邮箱的登录记录，请让新船长先使用该邮箱登录本站，再重试');
  const recipient:Captain=JSON.parse(matches.results[0].value);const account:any=await env.DB.prepare('SELECT transfer_code FROM accounts WHERE id=?').bind(recipient.userId).first();if(!account||typeof p.recipientCode!=='string'||p.recipientCode.trim()!==account.transfer_code)throw Error('接收权限码不匹配，请向新船长核实账户设置中的权限码');
  if(next.some(c=>c.userId===recipient.userId))throw Error('该账户已经是船长');
  if(p.operation==='add')next.push(recipient);
  else {const index=next.findIndex(c=>c.userId===p.targetId);if(index<0)throw Error('原船长不存在');next[index]=recipient;}
 }else throw Error('无效的权限操作');
 if(next.length<1||next.length>2)throw Error('工作台必须保留至少一位、最多两位船长');
 const result=await env.DB.prepare("UPDATE settings SET value=? WHERE key='captains' AND value=?").bind(JSON.stringify(next),ctx.revision).run();
 if(!result.meta.changes)throw Error('船长名单已变化，请刷新后重试');
}
