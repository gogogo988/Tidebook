import { captainContext } from './captains.mjs';
import { env } from './runtime.mjs';
import { getChatGPTUser } from './runtime.mjs';
export async function POST(req) { try {
    if (req.headers.get('origin') !== new URL(req.url).origin)
        return new Response('Forbidden', { status: 403 });
    const u = await getChatGPTUser();
    if (!u)
        return Response.json({ error: '请先登录' }, { status: 401 });
    if (!env.DB || !env.BUCKET)
        throw Error('文件服务暂不可用');
    const form = await req.formData();
    const file = form.get('file');
    const kind = form.get('kind') === 'catch' ? 'catch' : 'receipt';
    if (kind === 'catch') {
        const { admin } = await captainContext();
        if (!admin)
            return new Response('Forbidden', { status: 403 });
    }
    if (!file || !['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 5 * 1024 * 1024)
        throw Error('请上传不超过 5MB 的 JPG、PNG 或 WebP 图片');
    const id = crypto.randomUUID();
    await env.BUCKET.put(id, await file.arrayBuffer(), { httpMetadata: { contentType: file.type } });
    await env.DB.prepare('INSERT INTO files (id,user_id,kind,mime) VALUES (?,?,?,?)').bind(id, u.userId, kind, file.type).run();
    return Response.json({ id });
}
catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : '上传失败' }, { status: 400 });
} }
export async function GET(req) { try {
    if (!env.DB || !env.BUCKET)
        throw Error();
    const id = new URL(req.url).searchParams.get('id');
    const f = await env.DB.prepare('SELECT * FROM files WHERE id=?').bind(id).first();
    if (!f)
        return new Response('Not found', { status: 404 });
    const published = f.kind === 'catch' && await env.DB.prepare("SELECT id FROM catches WHERE EXISTS (SELECT 1 FROM json_each(catches.data,'$.photos') WHERE value=?)").bind(id).first();
    if (!published) {
        const u = await getChatGPTUser();
        const { admin } = await captainContext();
        if (!u || (u.userId !== f.user_id && !admin))
            return new Response('Forbidden', { status: 403 });
    }
    const o = await env.BUCKET.get(id);
    if (!o)
        return new Response('Not found', { status: 404 });
    return new Response(o.body, { headers: { 'Content-Type': f.mime, 'Cache-Control': 'private, no-store', 'X-Content-Type-Options': 'nosniff' } });
}
catch {
    return new Response('文件暂时无法读取', { status: 503 });
} }
