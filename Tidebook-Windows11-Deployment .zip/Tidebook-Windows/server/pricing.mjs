export function validatePricing(input) {
    const capacity = Number(input.capacity), minPeople = Number(input.minPeople);
    if (!Number.isInteger(capacity) || !Number.isInteger(minPeople) || minPeople < 1 || capacity > 100 || minPeople > capacity)
        throw Error('最少、最多人数须为 1–100 的整数，且最少人数不能超过最多人数');
    const prices = {};
    for (let count = minPeople; count <= capacity; count++) {
        const raw = input.prices?.[count], amount = Number(raw);
        if (raw === '' || raw == null || !Number.isFinite(amount) || amount < 1 || amount > 100000 || Math.abs(amount * 100 - Math.round(amount * 100)) > 0.000001)
            throw Error(`请填写 ${count} 人出船时的人均费用（1–100000 AUD，最多两位小数）`);
        prices[count] = amount;
    }
    const deposit = Number(input.deposit);
    if (!Number.isFinite(deposit) || deposit < 1 || Math.abs(deposit * 100 - Math.round(deposit * 100)) > 0.000001 || deposit > Math.min(...Object.values(prices)))
        throw Error('人均订金须至少为 1 AUD、最多两位小数，且不能高于任一人数档位的费用');
    return { capacity, minPeople, prices, deposit, price: prices[capacity] };
}
export function finalPriceFor(trip, actual) {
    if (!Number.isInteger(actual) || actual < (trip.minPeople ?? 1) || actual > trip.capacity)
        throw Error('实际人数必须在设定的最少和最多人数之间；不足最低人数不能结算');
    const price = trip.prices?.[actual];
    if (!Number.isFinite(price) || Number(price) < 1)
        throw Error('该人数没有收费标准，请先补全价格表');
    return Number(price);
}
export function priceRange(trip) {
    const values = trip.prices ? Object.values(trip.prices) : [trip.price];
    return [Math.min(...values), Math.max(...values)];
}
