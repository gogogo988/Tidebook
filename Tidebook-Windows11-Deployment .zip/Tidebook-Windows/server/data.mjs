import { captainContext, changeCaptains } from './captains.mjs';
import { validatePricing, finalPriceFor } from './pricing.mjs';
import { env } from './runtime.mjs';
const db = () => { if (!env.DB)
    throw Error('数据库暂不可用，请稍后重试'); return env.DB; };
const fail = (s) => { throw Error(s); };
const str = (v, n = 2000) => typeof v === 'string' ? v.trim().slice(0, n) : '';
const num = (v, min = 0, max = 100000) => { const n = Number(v); if (!Number.isFinite(n) || n < min || n > max)
    fail('数值超出允许范围'); return n; };
const context = captainContext;
export async function GET() { try {
    const { u, owner, admin, captains, revision } = await context();
    const [t, b, c] = await Promise.all([db().prepare('SELECT * FROM trips').all(), u ? (admin ? db().prepare('SELECT * FROM bookings') : db().prepare('SELECT * FROM bookings WHERE user_id=?').bind(u.userId)).all() : Promise.resolve({ results: [] }), db().prepare('SELECT * FROM catches').all()]);
    const counts = await db().prepare("SELECT trip_id,SUM(seats) AS used FROM bookings WHERE status IN ('pending','review','confirmed','paid') GROUP BY trip_id").all();
    return Response.json({ setup: !owner, admin, user: u?.email || '', username: u?.username || '', userId: u?.userId || '', captains: admin ? captains : [], captainsRevision: admin ? revision : null, trips: t.results.map((r) => ({ ...JSON.parse(r.data), id: r.id, status: r.status, capacity: r.capacity, used: counts.results.find((x) => x.trip_id === r.id)?.used || 0 })), bookings: b.results.map((r) => { const trip = t.results.find((x) => x.id === r.trip_id); const pricing = trip ? JSON.parse(trip.data) : {}; return { ...JSON.parse(r.data), pricingPending: !!pricing.prices && !pricing.settledAt && !['paid', 'cancelled'].includes(r.status), id: r.id, tripId: r.trip_id, isMine: r.user_id === u?.userId, status: r.status, seats: r.seats }; }), catches: c.results.map((r) => ({ ...JSON.parse(r.data), id: r.id, tripId: r.trip_id })) }, { headers: { 'Cache-Control': 'no-store' } });
}
catch (e) {
    console.error(e);
    return Response.json({ error: '数据暂时无法加载，请重试。' }, { status: 503 });
} }
export async function POST(req) {
    try {
        if (req.headers.get('origin') && req.headers.get('origin') !== new URL(req.url).origin)
            return Response.json({ error: '请求来源无效' }, { status: 403 });
        const ctx = await context();
        const { u, owner, admin } = ctx;
        if (!u)
            return Response.json({ error: '请先登录后继续' }, { status: 401 });
        const p = await req.json();
        const id = crypto.randomUUID();
        if (p.action === 'setup')
            fail('请在服务器电脑运行初始化脚本创建首位船长');
        if (p.action === 'captains') {
            await changeCaptains(p, ctx);
        }
        else if (p.action === 'trip') {
            if (!admin)
                fail('仅船长可发布船期');
            const d = p.data;
            const pricing = validatePricing(d);
            const capacity = pricing.capacity;
            if (!Number.isInteger(capacity))
                fail('人数必须为整数');
            if (!str(d.title) || !str(d.date) || !str(d.location) || !str(d.account))
                fail('请填写标题、日期、位置和收款账户');
            if (isNaN(Date.parse(d.date)) || Date.parse(d.date) < Date.now())
                fail('出发时间必须晚于当前时间');
            if (d.weatherUrl && !/^https?:\/\//.test(d.weatherUrl))
                fail('天气链接需要以 https:// 或 http:// 开头');
            const data = { ...Object.fromEntries(['title', 'date', 'location', 'fish', 'weather', 'weatherUrl', 'captain', 'boat', 'account', 'notes'].map(k => [k, str(d[k])])), ...pricing, created: new Date().toISOString() };
            if (data.deposit > data.price)
                fail('订金不能高于费用');
            if (p.id) {
                const previous = await db().prepare('SELECT * FROM trips WHERE id=?').bind(p.id).first();
                if (!previous)
                    fail('船期不存在');
                if (JSON.parse(previous.data).settledAt)
                    fail('已结算船期不能修改收费规则');
                const paid = await db().prepare("SELECT id FROM bookings WHERE trip_id=? AND status='paid' LIMIT 1").bind(p.id).first();
                if (paid)
                    fail('已有结清预约的旧船期保留原收费规则');
                const largest = await db().prepare("SELECT MAX(json_extract(data,'$.deposit')) AS amount FROM bookings WHERE trip_id=? AND status IN ('pending','review','confirmed')").bind(p.id).first();
                if (Number(largest?.amount || 0) > Math.min(...Object.values(pricing.prices)))
                    fail('费用不能低于已有预约的人均订金');
                const result = await db().prepare("UPDATE trips SET data=?,capacity=? WHERE id=? AND data=? AND status IN ('open','closed') AND NOT EXISTS (SELECT 1 FROM bookings WHERE trip_id=trips.id AND (status='paid' OR (status IN ('pending','review','confirmed') AND json_extract(data,'$.deposit') > ?))) AND ? >= COALESCE((SELECT SUM(seats) FROM bookings WHERE trip_id=? AND status IN ('pending','review','confirmed','paid')),0)").bind(JSON.stringify(data), capacity, p.id, previous.data, Math.min(...Object.values(pricing.prices)), capacity, p.id).run();
                if (!result.meta.changes)
                    fail('无法修改：船期已结束或新人数低于已报名人数');
            }
            else
                await db().prepare('INSERT INTO trips (id,data,status,capacity) VALUES (?,?,?,?)').bind(id, JSON.stringify(data), 'open', capacity).run();
        }
        else if (p.action === 'book') {
            const d = { ...p.data, name: p.data.name === undefined ? u.username : p.data.name };
            const seats = num(d.seats, 1, 20);
            if (!Number.isInteger(seats))
                fail('人数必须为整数');
            if (!str(d.name) || !str(d.phone))
                fail('请填写姓名和联系方式');
            const t = await db().prepare('SELECT * FROM trips WHERE id=?').bind(d.tripId).first();
            if (!t || t.status !== 'open' || Date.parse(JSON.parse(t.data).date) <= Date.now())
                fail('此船期已停止报名');
            const trip = JSON.parse(t.data);
            const data = { name: str(d.name, 80), phone: str(d.phone, 100), notes: str(d.notes), email: u.email, price: trip.price, pricingPending: !!trip.prices, deposit: trip.deposit, created: new Date().toISOString(), receipt: '', reference: '', refund: false };
            const r = await db().prepare("INSERT INTO bookings (id,trip_id,user_id,data,status,seats) SELECT ?,?,?,?,'pending',? WHERE EXISTS (SELECT 1 FROM trips WHERE id=? AND data=? AND status='open' AND capacity >= ? + COALESCE((SELECT SUM(seats) FROM bookings WHERE trip_id=? AND status IN ('pending','review','confirmed','paid')),0)) AND NOT EXISTS (SELECT 1 FROM bookings WHERE trip_id=? AND user_id=? AND status IN ('pending','review','confirmed','paid'))").bind(id, t.id, u.userId, JSON.stringify(data), seats, t.id, t.data, seats, t.id, t.id, u.userId).run();
            if (!r.meta.changes)
                fail('剩余名额不足，或您已有有效预约');
        }
        else if (p.action === 'booking') {
            const b = await db().prepare('SELECT * FROM bookings WHERE id=?').bind(p.id).first();
            if (!b || (!admin && b.user_id !== u.userId))
                fail('无权操作此预约');
            const tripRow = await db().prepare('SELECT * FROM trips WHERE id=?').bind(b.trip_id).first();
            const trip = JSON.parse(tripRow.data);
            if (trip.settledAt && !['paid', 'refunded'].includes(p.next))
                fail('实际人数已确认，预约已锁定；可继续核实尾款或退款');
            let d = JSON.parse(b.data), status = b.status;
            if (p.next === 'review') {
                if (!['pending', 'review'].includes(status))
                    fail('当前预约不能提交凭证');
                if (!str(p.reference) && !str(p.receipt))
                    fail('请填写转账参考号或上传凭证');
                if (p.receipt) {
                    const f = await db().prepare("SELECT id FROM files WHERE id=? AND user_id=? AND kind='receipt'").bind(p.receipt, u.userId).first();
                    if (!f)
                        fail('转账凭证无效');
                }
                d = { ...d, reference: str(p.reference), receipt: str(p.receipt) };
                status = 'review';
            }
            else if (p.next === 'cancelled') {
                if (status === 'cancelled')
                    fail('预约已取消');
                if (!['open', 'closed'].includes(tripRow.status))
                    fail('该船期已结束，不能取消报名');
                if (p.expectedStatus && p.expectedStatus !== status)
                    fail('预约状态已变化，请刷新并核实付款状态后再取消');
                d.cancelReason = str(p.reason, 500);
                d.cancelledBy = admin ? 'captain' : 'angler';
                d.cancelledAt = new Date().toISOString();
                status = 'cancelled';
                d.refundDue = ['confirmed', 'paid'].includes(b.status) ? (b.status === 'paid' ? d.price : d.deposit) * b.seats : 0;
            }
            else {
                if (!admin)
                    fail('仅船长可以核实收款');
                if (p.next === 'confirmed' && status === 'review')
                    status = 'confirmed';
                else if (p.next === 'pending' && status === 'review')
                    status = 'pending';
                else if (p.next === 'paid' && status === 'confirmed') {
                    if (trip.prices && !trip.settledAt)
                        fail('请先在船期详情确认实际人数并结算');
                    status = 'paid';
                }
                else if (p.next === 'refunded' && status === 'cancelled' && d.refundDue)
                    d.refund = true;
                else
                    fail('不支持此状态变更');
            }
            ;
            const result = await db().prepare('UPDATE bookings SET data=?,status=? WHERE id=? AND status=? AND data=? AND EXISTS (SELECT 1 FROM trips WHERE id=? AND data=? AND status=?)').bind(JSON.stringify(d), status, b.id, b.status, b.data, b.trip_id, tripRow.data, tripRow.status).run();
            if (!result.meta.changes)
                fail('预约已更新，请刷新后重试');
            if (p.next === 'cancelled')
                return Response.json({ ok: true, releasedSeats: b.seats });
        }
        else if (p.action === 'settle') {
            if (!admin)
                fail('仅船长可确认实际人数');
            const t = await db().prepare('SELECT * FROM trips WHERE id=?').bind(p.id).first();
            if (!t || !['open', 'closed', 'completed'].includes(t.status))
                fail('此船期不能结算');
            const trip = JSON.parse(t.data);
            if (trip.settledAt)
                fail('该船期已结算，请刷新查看');
            if (Date.parse(trip.date) > Date.now())
                fail('出发后才能确认实际出船人数');
            const actualPeople = Number(p.actualPeople), finalPrice = finalPriceFor({ ...trip, capacity: t.capacity }, actualPeople);
            const settledAt = new Date().toISOString() + '-' + crypto.randomUUID();
            const data = { ...trip, actualPeople, finalPrice, settledAt };
            const results = await db().batch([
                db().prepare("UPDATE trips SET data=?,status=CASE WHEN status='open' THEN 'closed' ELSE status END WHERE id=? AND data=? AND status=? AND NOT EXISTS (SELECT 1 FROM bookings WHERE trip_id=? AND status IN ('pending','review','paid')) AND ?=COALESCE((SELECT SUM(seats) FROM bookings WHERE trip_id=? AND status='confirmed'),0) AND NOT EXISTS (SELECT 1 FROM bookings WHERE trip_id=? AND status='confirmed' AND json_extract(data,'$.deposit')>?)").bind(JSON.stringify(data), p.id, t.data, t.status, p.id, actualPeople, p.id, p.id, finalPrice),
                db().prepare("UPDATE bookings SET data=json_set(data,'$.price',?,'$.pricingPending',json('false'),'$.actualPeople',?,'$.settledAt',?) WHERE trip_id=? AND status='confirmed' AND EXISTS (SELECT 1 FROM trips WHERE id=? AND json_extract(data,'$.settledAt')=?)").bind(finalPrice, actualPeople, settledAt, p.id, p.id, settledAt)
            ]);
            if (!results[0].meta.changes)
                fail('无法结算：请先处理所有待付或待核实预约、取消未出船预约，并确保实际人数等于已确认预约人数。数据变化后请刷新重试。');
        }
        else if (p.action === 'tripStatus') {
            if (!admin)
                fail('仅船长可管理船期');
            if (!['closed', 'completed', 'cancelled'].includes(p.status))
                fail('无效状态');
            const t = await db().prepare('SELECT * FROM trips WHERE id=?').bind(p.id).first();
            if (!t || ['completed', 'cancelled'].includes(t.status))
                fail('该船期已结束');
            if (p.status === 'completed' && JSON.parse(t.data).prices && !JSON.parse(t.data).settledAt)
                fail('请先确认实际人数并结算，再标记已结束');
            if (p.status === 'cancelled' && JSON.parse(t.data).settledAt)
                fail('已确认实际出船人数的船期不能取消');
            if (p.status === 'completed' && Date.parse(JSON.parse(t.data).date) > Date.now())
                fail('未出发船期不能标记结束');
            if (p.status === 'cancelled') {
                const results = await db().batch([db().prepare('UPDATE trips SET status=? WHERE id=? AND data=? AND status=?').bind(p.status, p.id, t.data, t.status), db().prepare("UPDATE bookings SET data=json_set(data,'$.refundDue',CASE WHEN status='paid' THEN json_extract(data,'$.price')*seats WHEN status='confirmed' THEN json_extract(data,'$.deposit')*seats ELSE 0 END),status='cancelled' WHERE trip_id=? AND status!='cancelled' AND EXISTS (SELECT 1 FROM trips WHERE id=? AND status='cancelled' AND data=?)").bind(p.id, p.id, t.data)]);
                if (!results[0].meta.changes)
                    fail('船期已更新，请刷新后重试');
            }
            else {
                const result = await db().prepare('UPDATE trips SET status=? WHERE id=? AND data=? AND status=?').bind(p.status, p.id, t.data, t.status).run();
                if (!result.meta.changes)
                    fail('船期已更新，请刷新后重试');
            }
            ;
        }
        else if (p.action === 'catch') {
            if (!admin)
                fail('仅船长可发布钓获');
            const d = p.data;
            const t = await db().prepare('SELECT * FROM trips WHERE id=?').bind(d.tripId).first();
            if (!t || t.status !== 'completed')
                fail('请先将船期标记为已结束');
            if (!str(d.fish))
                fail('请填写鱼种');
            const count = num(d.count, 0, 10000), weight = num(d.weight, 0, 100000);
            if (!Number.isInteger(count))
                fail('尾数需要为整数');
            const photos = Array.isArray(d.photos) ? d.photos.slice(0, 6) : [];
            for (const photo of photos) {
                if (!await db().prepare("SELECT id FROM files WHERE id=? AND user_id=? AND kind='catch'").bind(photo, u.userId).first())
                    fail('照片无效');
            }
            await db().prepare('INSERT INTO catches (id,trip_id,data) VALUES (?,?,?)').bind(id, t.id, JSON.stringify({ fish: str(d.fish), count, weight, notes: str(d.notes), photos, created: new Date().toISOString() })).run();
        }
        else if (p.action === 'memberNote') {
            if (!admin)
                fail('仅船长可编辑备注');
            const b = await db().prepare('SELECT * FROM bookings WHERE id=?').bind(p.id).first();
            if (!b)
                fail('预约不存在');
            await db().prepare("UPDATE bookings SET data=json_set(data,'$.captainNote',?) WHERE id=?").bind(str(p.note), p.id).run();
        }
        else
            fail('未知操作');
        return Response.json({ ok: true, id });
    }
    catch (e) {
        console.error(e);
        return Response.json({ error: e instanceof Error ? e.message : '保存失败，请稍后重试' }, { status: 400 });
    }
}
