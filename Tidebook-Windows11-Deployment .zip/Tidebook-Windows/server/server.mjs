import http from 'node:http';import path from 'node:path';import {existsSync,readFileSync,statSync} from 'node:fs';
import {root,dataDir,sqlite,requestContext} from './runtime.mjs';import {token,hash,passwordHash,passwordMatches,validEmail} from './security.mjs';
import * as data from './data.mjs';import * as file from './file.mjs';
const port=Number(process.env.PORT||8787);if(!sqlite.prepare("SELECT value FROM settings WHERE key='owner'").get()){console.error('Run 01-Initialize.cmd first.');process.exit(1)}
const localHosts=new Set([`127.0.0.1:${port}`,`localhost:${port}`]);const rates=new Map();let hashes=0;
function limit(key,max){const now=Date.now();if(rates.size>10000)for(const[k,v]of rates)if(v.until<now)rates.delete(k);const v=rates.get(key);if(!v||v.until<now){rates.set(key,{count:1,until:now+15*60*1000});return false}return ++v.count>max}
const json=(data,status=200,headers={})=>Response.json(data,{status,headers});
const cookie=(value,secure,age)=>`tidebook_session=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${secure?'; Secure':''}`;
function session(req){const raw=(req.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('tidebook_session='))?.slice(17);if(!raw||!/^[a-f0-9]{64}$/.test(raw))return null;return sqlite.prepare('SELECT accounts.*,sessions.hash AS session_hash FROM sessions JOIN accounts ON accounts.id=sessions.user_id WHERE sessions.hash=? AND sessions.expires>?').get(hash(raw),Date.now())}
async function dispatch(req,pathname,secure,ip){
 const account=session(req);const user=account?{userId:account.id,email:account.email,username:account.username||account.email.split('@')[0]}:null;
 if(pathname==='/health')return json({ok:true});
 if(pathname==='/api/auth/session'&&req.method==='GET')return json({user:account?{email:account.email,username:account.username||account.email.split('@')[0],transferCode:account.transfer_code}:null});
 if(pathname.startsWith('/api/auth/')&&req.method==='POST'){
  if(req.headers.get('content-type')?.split(';')[0]!=='application/json')return json({error:'请使用页面表单'},415);
  const p=await req.json();const email=typeof p.email==='string'?p.email.trim().toLowerCase():'';
  if(pathname==='/api/auth/logout'){if(account)sqlite.prepare('DELETE FROM sessions WHERE hash=?').run(account.session_hash);return json({ok:true},200,{'Set-Cookie':cookie('',secure,0)})}
  if(pathname==='/api/auth/profile'){if(!account)return json({error:'请先登录'},401);const username=typeof p.username==='string'?p.username.trim():'';if(!username||username.length>40)return json({error:'请输入 1–40 个字符的用户名'},400);sqlite.prepare('UPDATE accounts SET username=? WHERE id=?').run(username,account.id);return json({ok:true})}
  if(!['/api/auth/login','/api/auth/register','/api/auth/password'].includes(pathname))return json({error:'未知操作'},404);
  if(limit('ip:'+ip,40)||limit('global',300)||limit('email:'+email,20))return json({error:'尝试过于频繁，请 15 分钟后再试'},429);
  if(hashes>=4)return json({error:'系统繁忙，请稍后重试'},429);hashes++;
  try{
   if(['/api/auth/password','/api/auth/register'].includes(pathname)&&(typeof p.password!=='string'||p.password.length<6||p.password.length>12))return json({error:'密码长度须为 6–12 个字符'},400);
   if(pathname==='/api/auth/password'){if(!account)return json({error:'请先登录'},401);if(!await passwordMatches(p.oldPassword,account.password))return json({error:'原密码错误'},400);const encoded=await passwordHash(p.password);sqlite.prepare('UPDATE accounts SET password=? WHERE id=?').run(encoded,account.id);sqlite.prepare('DELETE FROM sessions WHERE user_id=?').run(account.id);return json({ok:true},200,{'Set-Cookie':cookie('',secure,0)})}
   if(!validEmail(email))return json({error:'请输入有效邮箱'},400);
   let a=sqlite.prepare('SELECT * FROM accounts WHERE email=?').get(email);
   if(pathname==='/api/auth/register'){
    if(a)return json({error:'该邮箱无法注册，请登录或联系船长'},400);
    const username=typeof p.username==='string'?p.username.trim():'';if(!username||username.length>40)return json({error:'请输入 1–40 个字符的用户名'},400);
    const encoded=await passwordHash(p.password);const id=crypto.randomUUID();
    sqlite.prepare('INSERT INTO accounts (id,email,password,transfer_code,username) VALUES (?,?,?,?,?)').run(id,email,encoded,token().slice(0,24),username);a=sqlite.prepare('SELECT * FROM accounts WHERE id=?').get(id);
   }else{
    const dummy='00000000000000000000000000000000:'+('00'.repeat(64));const matches=await passwordMatches(p.password,a?.password||dummy);if(!a||!matches)return json({error:'邮箱或密码不正确'},401);
   }
   const raw=token();sqlite.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());sqlite.prepare('INSERT INTO sessions VALUES (?,?,?)').run(hash(raw),a.id,Date.now()+7*86400000);return json({ok:true},200,{'Set-Cookie':cookie(raw,secure,7*86400)});
  }finally{hashes--}
 }
 return requestContext.run({user},async()=>{
  if(pathname==='/api/data')return req.method==='GET'?data.GET():req.method==='POST'?data.POST(req):json({error:'Method not allowed'},405);
  if(pathname==='/api/file')return req.method==='GET'?file.GET(req):req.method==='POST'?file.POST(req):json({error:'Method not allowed'},405);
  if(pathname.startsWith('/api/'))return json({error:'Not found'},404);
  if(req.method!=='GET'&&req.method!=='HEAD')return json({error:'Method not allowed'},405);
  const requested=pathname==='/account'?'account.html':pathname==='/'?'index.html':decodeURIComponent(pathname).slice(1);
  const target=path.resolve(root,'web',requested);if(!target.startsWith(path.resolve(root,'web')+path.sep)||!existsSync(target)||!statSync(target).isFile())return new Response('Not found',{status:404});
  const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.woff2':'font/woff2'};
  return new Response(req.method==='HEAD'?null:readFileSync(target),{headers:{'Content-Type':mime[path.extname(target)]||'application/octet-stream'}});
 });
}
const server=http.createServer(async(incoming,out)=>{try{
 const host=incoming.headers.host;let publicOrigin='';try{publicOrigin=JSON.parse(readFileSync(path.join(dataDir,'public-origin.json'),'utf8')).origin}catch{}
 const external=publicOrigin&&host===new URL(publicOrigin).host;
 if(!localHosts.has(host)&&!external){out.writeHead(403);out.end('Unrecognized host');return}
 const origin=external?publicOrigin:`http://${host}`;const url=new URL(incoming.url,origin);if(url.origin!==origin)throw Error('Invalid request URL');
 if(!['GET','HEAD'].includes(incoming.method)&&incoming.headers.origin!==origin){out.writeHead(403);out.end('Origin rejected');return}
 const cap=url.pathname==='/api/file'?6*1024*1024:64*1024;let size=0;const chunks=[];
 for await(const chunk of incoming){size+=chunk.length;if(size>cap){out.writeHead(413);out.end('Request too large');return}chunks.push(chunk)}
 const headers=new Headers();for(const[k,v]of Object.entries(incoming.headers))if(v)headers.set(k,Array.isArray(v)?v.join(','):v);
 // Never derive identity from user-supplied headers.
 const req=new Request(url,{method:incoming.method,headers,...(!['GET','HEAD'].includes(incoming.method)?{body:Buffer.concat(chunks)}:{})});
 const ip=external?String(incoming.headers['cf-connecting-ip']||'tunnel'):'local';
 const response=await dispatch(req,url.pathname,!!external,ip);
 const result=Object.fromEntries(response.headers);Object.assign(result,{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"});
 out.writeHead(response.status,result);out.end(Buffer.from(await response.arrayBuffer()));
}catch(e){console.error(e.message);if(!out.headersSent){out.writeHead(400,{'Content-Type':'application/json'});out.end(JSON.stringify({error:'请求失败，请检查输入或稍后重试'}))}else out.end()}});
server.requestTimeout=30000;server.headersTimeout=15000;server.listen(port,'127.0.0.1',()=>console.log(`Tidebook ready: http://127.0.0.1:${port} (Ctrl+C to stop)`));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>{sqlite.close();process.exit(0)}));
