import {request as httpRequest} from 'node:http';
import assert from 'node:assert/strict';import {spawn,spawnSync}from'node:child_process';import{mkdtempSync,readFileSync,writeFileSync,existsSync,rmSync}from'node:fs';import{tmpdir}from'node:os';import path from'node:path';import{DatabaseSync}from'node:sqlite';
const dir=mkdtempSync(path.join(tmpdir(),'tidebook-test-'));const env={...process.env,TIDEBOOK_DATA_DIR:dir,PORT:'18787'};const pass='Tidebook123';
const init=spawnSync(process.execPath,['server/admin.mjs','init'],{env,input:JSON.stringify({email:'captain@example.com',password:pass}),encoding:'utf8'});assert.equal(init.status,0,init.stderr);
// Simulate the previous account schema and a legacy password longer than 12 characters.
const {scryptSync}=await import('node:crypto');const legacyPass='Legacy-long-password-2026';
const legacyDb=new DatabaseSync(path.join(dir,'tidebook.sqlite'));legacyDb.exec('ALTER TABLE accounts DROP COLUMN username');
const salt='1234567890abcdef1234567890abcdef';legacyDb.prepare('UPDATE accounts SET password=?').run(salt+':'+scryptSync(legacyPass,salt,64,{N:32768,r:8,p:1,maxmem:64*1024*1024}).toString('hex'));legacyDb.close();
const child=spawn(process.execPath,['server/server.mjs'],{env,stdio:['ignore','pipe','pipe']});let logs='';child.stderr.on('data',d=>logs+=d);
const base='http://127.0.0.1:18787';
async function call(url,body,cookie='',expected=200,extra={}){
 const response=await new Promise((resolve,reject)=>{const req=httpRequest(base+url,{method:body===undefined?'GET':'POST',headers:{Origin:base,...(body===undefined?{}:{'Content-Type':'application/json'}),Cookie:cookie,...extra}},res=>{let text='';res.on('data',c=>text+=c);res.on('end',()=>resolve({status:res.statusCode,text,headers:res.headers}))});req.on('error',reject);req.end(body===undefined?undefined:JSON.stringify(body))});
 assert.equal(response.status,expected,response.text);let data;try{data=JSON.parse(response.text)}catch{data=response.text}
 const headers=new Headers();for(const[k,v]of Object.entries(response.headers))if(v)headers.set(k,Array.isArray(v)?v.join(','):v);
 return {data,cookie:headers.get('set-cookie')?.split(';')[0],headers};
}

try{
 for(let i=0;i<100;i++){try{await fetch(base+'/health');break}catch{await new Promise(r=>setTimeout(r,50))}}
 assert.equal((await call('/api/data')).data.admin,false);
 const owner=(await call('/api/auth/login',{email:'captain@example.com',password:legacyPass})).cookie;assert(owner);
 await call('/api/auth/login',{email:'captain@example.com',password:'incorrect'},'',401);
 for(const password of ['12345','1234567890123'])await call('/api/auth/register',{email:'invalid@example.com',username:'Test',password},'',400);
 await call('/api/auth/register',{email:'invalid@example.com',username:'   ',password:pass},'',400);
 const six=(await call('/api/auth/register',{email:'six@example.com',username:'Six',password:'123456'})).cookie;
 await call('/api/auth/password',{oldPassword:'123456',password:'123456789012'},six);
 assert((await call('/api/auth/login',{email:'six@example.com',password:'123456789012'})).cookie);
 assert.equal((await call('/api/auth/session',undefined,owner)).data.user.username,'captain');
 const a=(await call('/api/auth/register',{email:'a@example.com',username:'海钓阿明',password:pass})).cookie;
 const b=(await call('/api/auth/register',{email:'b@example.com',username:'小陈',password:pass})).cookie;
 assert.equal((await call('/api/data',undefined,a)).data.username,'海钓阿明');
 await call('/api/auth/profile',{username:'陈小海'},b);assert.equal((await call('/api/auth/session',undefined,b)).data.user.username,'陈小海');
 const state=(await call('/api/data',undefined,owner)).data;assert.equal(state.admin,true);
 await call('/api/data',{action:'setup'},a,400);
 const trip={title:'Test trip',date:'2099-01-01T06:00:00+11:00',location:'Pier',account:'Bank test',capacity:2,minPeople:1,prices:{1:500,2:300},deposit:100};
 await call('/api/data',{action:'trip',data:trip},a,400);
 const tripId=(await call('/api/data',{action:'trip',data:trip},owner)).data.id;
 const booking=(await call('/api/data',{action:'book',data:{tripId,phone:'123',seats:2}},a)).data.id;
 const own=(await call('/api/data',undefined,a)).data.bookings[0];assert.equal(own.name,'海钓阿明');assert.equal(own.isMine,true);
 await call('/api/data',{action:'book',data:{tripId,name:'B',phone:'456',seats:1}},b,400);
 assert.equal((await call('/api/data',undefined,b)).data.bookings.length,0);
 await call('/api/data',{action:'booking',id:booking,next:'cancelled'},b,400);
 const released=(await call('/api/data',{action:'booking',id:booking,next:'cancelled',expectedStatus:'pending',reason:'Unpaid'},owner)).data;assert.equal(released.releasedSeats,2);
 const bookingB=(await call('/api/data',{action:'book',data:{tripId,name:'B',phone:'456',seats:2}},b)).data.id;
 const form=new FormData();form.set('kind','receipt');form.set('file',new File([Buffer.from('89504e470d0a1a0a','hex')],'proof.png',{type:'image/png'}));
 const upload=await fetch(base+'/api/file',{method:'POST',headers:{Origin:base,Cookie:b},body:form});assert.equal(upload.status,200);const fid=(await upload.json()).id;
 await call('/api/file?id='+fid,undefined,a,403);await call('/api/file?id='+fid,undefined,owner);
 await call('/api/data',{action:'booking',id:bookingB,next:'review',receipt:fid,reference:'Transfer'},b);
 await call('/api/data',{action:'booking',id:bookingB,next:'confirmed'},owner);
 const db=new DatabaseSync(path.join(dir,'tidebook.sqlite'));let td=JSON.parse(db.prepare('SELECT data FROM trips WHERE id=?').get(tripId).data);td.date='2020-01-01T06:00:00+11:00';db.prepare('UPDATE trips SET data=? WHERE id=?').run(JSON.stringify(td),tripId);db.close();
 await call('/api/data',{action:'settle',id:tripId,actualPeople:2},owner);
 const settled=(await call('/api/data',undefined,b)).data.bookings[0];assert.equal(settled.price,300);assert.equal((settled.price-settled.deposit)*settled.seats,400);
 const code=(await call('/api/auth/session',undefined,a)).data.user.transferCode;
 await call('/api/data',undefined,a);
 let revision=(await call('/api/data',undefined,owner)).data.captainsRevision;
 await call('/api/data',{action:'captains',operation:'add',revision,email:'a@example.com',recipientCode:'wrong'},owner,400);
 await call('/api/data',{action:'captains',operation:'add',revision,email:'a@example.com',recipientCode:code},owner);
 assert.equal((await call('/api/data',undefined,a)).data.admin,true);
 revision=(await call('/api/data',undefined,a)).data.captainsRevision;
 const ownerId=(await call('/api/data',undefined,owner)).data.userId;
 await call('/api/data',{action:'captains',operation:'remove',revision,targetId:ownerId},a);
 assert.equal((await call('/api/data',undefined,owner)).data.admin,false);
 assert.equal((await call('/api/data',undefined,'',200,{'oai-authenticated-user-id':ownerId,'oai-authenticated-user-email':'captain@example.com'})).data.admin,false);
 await call('/api/data',{action:'trip',data:trip},a,403,{Origin:'https://evil.example'});
 await call('/api/data',undefined,'',403,{Host:'evil.example'});
 await call('/data/tidebook.sqlite',undefined,'',404);
 await call('/api/auth/password',{oldPassword:pass,password:'Newpass123'},b);assert.equal((await call('/api/auth/session',undefined,b)).data.user,null);
 const logout=await call('/api/auth/logout',{},a);assert.match(logout.headers.get('set-cookie'),/Max-Age=0/);assert.equal((await call('/api/auth/session',undefined,a)).data.user,null);
 writeFileSync(path.join(dir,'public-origin.json'),JSON.stringify({origin:'https://sample-test.trycloudflare.com'}));
 const pub=await call('/api/auth/login',{email:'a@example.com',username:'海钓阿明',password:pass},'',200,{Host:'sample-test.trycloudflare.com',Origin:'https://sample-test.trycloudflare.com'});assert.match(pub.headers.get('set-cookie'),/Secure/);
 console.log('PASS: legacy schema/password migration, username defaults/profile, 6–12 password boundaries, real accounts, sessions, capacity/rebooking, receipts isolation, pricing settlement, two captains, account-code transfer, revocation, CSRF, host validation, private files, password changes and secure tunnel cookies.');
}finally{child.kill('SIGTERM');await new Promise(resolve=>child.once('exit',resolve));if(logs.includes('SyntaxError'))throw Error(logs)}
const backup=spawnSync(process.execPath,['server/admin.mjs','backup'],{env,encoding:'utf8'});assert.equal(backup.status,0,backup.stderr);const backupPath=backup.stdout.match(/Backup: (.+)/)[1].trim();const restored=new DatabaseSync(path.join(backupPath,'tidebook.sqlite'));assert.equal(restored.prepare('SELECT COUNT(*) AS n FROM bookings').get().n,2);restored.close();rmSync(backupPath,{recursive:true});rmSync(dir,{recursive:true});console.log('PASS: stopped-server backup contains accounts and bookings.');
