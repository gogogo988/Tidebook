DELETE FROM `catches`;
--> statement-breakpoint
DELETE FROM `bookings`;
--> statement-breakpoint
DELETE FROM `trips`;
--> statement-breakpoint
DELETE FROM `files`;
--> statement-breakpoint
DELETE FROM `settings`;
