@echo off
set "TIDEBOOK_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%TIDEBOOK_POWERSHELL%" (
 echo Windows PowerShell was not found at its standard system location.
 exit /b 1
)
set "TIDEBOOK_NODE="
if exist "%ProgramFiles%\nodejs\node.exe" set "TIDEBOOK_NODE=%ProgramFiles%\nodejs\node.exe"
if not defined TIDEBOOK_NODE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "TIDEBOOK_NODE=%LOCALAPPDATA%\Programs\nodejs\node.exe"
if not defined TIDEBOOK_NODE for /f "delims=" %%N in ('"%SystemRoot%\System32\where.exe" node.exe 2^>nul') do if not defined TIDEBOOK_NODE set "TIDEBOOK_NODE=%%N"
if not defined TIDEBOOK_NODE (
 echo Node.js not found. Install Node.js 24 LTS from https://nodejs.org/en/download
 exit /b 1
)
for %%N in ("%TIDEBOOK_NODE%") do set "PATH=%%~dpN;%SystemRoot%\System32;%SystemRoot%\System32\WindowsPowerShell\v1.0;%PATH%"
"%TIDEBOOK_NODE%" "%~dp0check-node.mjs"
exit /b %errorlevel%
