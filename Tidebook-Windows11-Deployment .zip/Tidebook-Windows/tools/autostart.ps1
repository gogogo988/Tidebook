param([switch]$Remove)
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
$startup=[Environment]::GetFolderPath('Startup')
$link=Join-Path $startup 'Tidebook-Server.lnk'
if($Remove){if(Test-Path $link){Remove-Item -LiteralPath $link};Write-Host 'Auto-start removed. Running windows are unchanged.';exit}
if(Test-Path $link){throw 'Tidebook startup shortcut already exists. Remove it with 07-Disable-Autostart.cmd first.'}
$wsh=New-Object -ComObject WScript.Shell
$shortcut=$wsh.CreateShortcut($link)
$shortcut.TargetPath=Join-Path $root '02-Start.cmd'
$shortcut.WorkingDirectory=$root
$shortcut.Save()
Write-Host 'Server starts after this Windows user signs in. The public tunnel must still be started manually.'
