param([ValidateSet('init','reset-password')][string]$Action='init')
$ErrorActionPreference='Stop'
Set-Location (Split-Path $PSScriptRoot -Parent)
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$OutputEncoding = [Console]::OutputEncoding
if (-not $env:TIDEBOOK_NODE) { $env:TIDEBOOK_NODE=(Get-Command node -ErrorAction Stop).Source }
$accountEmail=Read-Host 'Account email'
$secure=Read-Host 'Password (6-12 characters)' -AsSecureString
$secureAgain=Read-Host 'Repeat password' -AsSecureString
$a=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
$b=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureAgain)
try {
 $pw=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($a)
 $again=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($b)
 if($pw -cne $again){throw 'Passwords do not match.'}
 @{email=$accountEmail;password=$pw} | ConvertTo-Json -Compress | & $env:TIDEBOOK_NODE server/admin.mjs $Action
 if($LASTEXITCODE -ne 0){throw 'Operation failed. Read the error above.'}
} finally {
 [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($a)
 [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b)
 $pw=$null; $again=$null
}
