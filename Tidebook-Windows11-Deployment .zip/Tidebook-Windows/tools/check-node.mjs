if(Number(process.versions.node.split('.')[0])<24){console.error('Install Node.js 24 LTS or newer first: https://nodejs.org/en/download');process.exit(1)}
