﻿﻿潮汐 Windows 11 自托管试用部署包

请先解压，再双击 START-HERE.html 阅读完整中文说明。

安装 Node.js 24 LTS 与 cloudflared 后，依次运行：
01-Initialize.cmd（仅首次）
02-Start.cmd
03-Public-Link.cmd

此包包含已编译网页，无需安装 npm 依赖即可运行服务。
本地数据与现有线上 tidebook 完全独立。临时通道只适合试用。
测试边界见 START-HERE.html。

版本 1.1.0：用户名自动带入报名、6–12 位新密码、船期卡片直接报名/提交订金。
升级：先停止网站和通道并运行 04 备份，再覆盖同名程序文件。
保留原 data、backups 和 tools/cloudflared.exe。不要重新初始化。
运行 02，浏览器 Ctrl+F5；完整升级说明见 START-HERE.html。
